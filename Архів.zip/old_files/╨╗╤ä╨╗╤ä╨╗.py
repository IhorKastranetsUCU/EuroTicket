import requests

API_KEY = "6xhdqY0A-z70P8i2uK07WgKKpcjNQZl3GQ9FzPt6ZK8KAwpRXKhcOdl1Zdw_bSMgTG2UfU-VNwHVJUyNS-IzQg"
BASE_URL = "https://pdp-api.plk-sa.pl"

url = f"{BASE_URL}/api/v1/data-version"

headers = {
    "X-API-Key": API_KEY
}

response = requests.get(url, headers=headers)

print("Status code:", response.status_code)
print("Response:")
print(response.text)